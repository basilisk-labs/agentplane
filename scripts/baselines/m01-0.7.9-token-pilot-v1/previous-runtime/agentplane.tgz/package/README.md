<p align="center">
  <img src="https://raw.githubusercontent.com/basilisk-labs/agentplane/main/docs/assets/readme-headers/agentplane-cli.svg" alt="Agentplane CLI package header" style="width:100%;max-width:100%;"/>
</p>

# Agentplane CLI

**The Git-native control plane for coding agents.**

`agentplane` is a local-first CLI that puts Claude Code, Codex, Cursor, Aider, and similar coding
agents on an approved, verifiable repository workflow. It bounds delegated work, holds approval
gates, independently observes repository and Git facts, and records verification, recovery, and
closure.

Let agents write code. Keep authority and proof in Git.

[![npm](https://img.shields.io/npm/v/agentplane.svg)](https://www.npmjs.com/package/agentplane)
[![Downloads](https://img.shields.io/npm/dm/agentplane.svg)](https://www.npmjs.com/package/agentplane)
[![GitHub stars](https://img.shields.io/github/stars/basilisk-labs/agentplane?style=flat)](https://github.com/basilisk-labs/agentplane/stargazers)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://github.com/basilisk-labs/agentplane/blob/main/LICENSE)
[![Node.js 24+](https://img.shields.io/badge/Node.js-24%2B-3c873a.svg)](https://agentplane.org/docs/user/prerequisites)

[![SLSA v1 provenance](https://img.shields.io/badge/SLSA-v1-success)](https://registry.npmjs.org/-/npm/v1/attestations/agentplane@latest)
[![Trusted publisher](https://img.shields.io/badge/npm-trusted%20publisher-blue)](https://docs.npmjs.com/generating-provenance-statements)
[![Recipes signed: Ed25519](https://img.shields.io/badge/recipes-Ed25519%20signed-111827)](https://agentplane.org/docs/recipes)

## Install in 30 seconds

```bash
npm i -g agentplane
agentplane init
agentplane quickstart
```

Prefer no global install:

```bash
npx agentplane init
npx agentplane quickstart
```

Requirements: Node.js 24+, Git, and a local terminal.

Experimental agent shorthand:

```bash
ap next
ap show <task-id>
ap vshow <task-id>
```

`ap` is an agent-optimized entrypoint for compact, non-interactive command use. Keep public docs and
human-facing setup on `agentplane`; use `ap` only when the installed package exposes it.

## What you get after `agentplane init`

```text
AGENTS.md or CLAUDE.md   Policy gateway for the repository
.agentplane/            Repo-local workflow workspace
.agentplane/WORKFLOW.md Current workflow/config contract
.agentplane/agents/     Installed agent profiles
.agentplane/tasks/      Per-task records and evidence
.agentplane/workflows/  Last-known-good workflow snapshot
```

Agentplane records the control and evidence trail inside the repository you already review.

## One task loop

```bash
agentplane task new --title "Fix parser edge case" --description "Reject empty labels." --owner <agent-id> --tag code
agentplane task advance <task-id> --agent-json
# Give the returned WorkOrder to Claude Code, Codex, Cursor, Aider, or another agent.
agentplane task advance <task-id> --result <exchange-directory>/result.json --agent-json
```

`task advance` owns deterministic lifecycle transitions and returns one compact semantic action at a
time. Use `agentplane task run <task-id>` when AgentPlane should invoke the configured managed
runner itself. In both modes the visible record keeps task intent, plan, observed verification,
evaluator result, token usage, closure, and ACR reviewable from Git-visible files.

Agent IDs are configurable profiles. See
[Agents](https://agentplane.org/docs/user/agents).

## Agent Change Record

Every task can produce an **Agent Change Record (ACR)**, a commit-safe JSON evidence projection of
intent, accepted plan, Git commits, policy decisions, verification result, and merge readiness.

```bash
agentplane acr generate <task-id> --work-commit HEAD --write
agentplane acr validate <task-id> --mode local
agentplane acr check <task-id> --mode ci
agentplane acr explain <task-id>
```

Schema: https://agentplane.org/schemas/acr-v0.1.schema.json

## Workflow modes

- `direct` keeps work in the current checkout for fast local loops.
- `branch_pr` creates per-task branches, worktrees, PR artifacts, and integration handoff.

## Worker and control plane

Your coding agent reasons, edits, tests, and reports a result. Agentplane bounds its authority,
holds material approval boundaries, observes repository and Git state, and determines whether the
lifecycle can close or needs recovery.

```text
authorize -> dispatch -> observe -> verify -> close or recover
```

Agentplane does not replace your coding agent, editor, terminal, Git, CI, or PR review.

## Compatible with

Claude Code, Codex CLI, Cursor agent, Aider, GitHub Actions agent runners, and MCP-driven
workflows. Agentplane does not replace them; it controls the delegated workflow and records what
the supervisor observed.

## Recipes

Recipes are optional signed behavior modules. Start with the task -> plan -> verify -> ACR flow
first; add recipes only when you need reusable profiles, prompt modules, skills, or repository
mapping:

```bash
agentplane recipes list-remote
agentplane recipes install code-map --refresh --yes
```

Start with [Code Map](https://agentplane.org/docs/recipes/code-map).

## Docs

- [Overview](https://agentplane.org/docs/user/overview)
- [Setup](https://agentplane.org/docs/user/setup)
- [Task lifecycle](https://agentplane.org/docs/user/task-lifecycle)
- [Workflow guides](https://agentplane.org/docs/workflow-guides)
- [Recipes](https://agentplane.org/docs/recipes)
- [Comparison](https://agentplane.org/docs/compare)

## Repository

https://github.com/basilisk-labs/agentplane

## License

MIT
